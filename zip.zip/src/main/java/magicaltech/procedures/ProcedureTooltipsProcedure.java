package magicaltech.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.Entity;
import net.minecraft.client.gui.screen.Screen;

import magicaltech.item.TrueRuneItem;
import magicaltech.item.TerraSpiritualIngotItem;
import magicaltech.item.SkieumIngotItem;
import magicaltech.item.FalseRuneItem;
import magicaltech.item.EmptyRuneItem;
import magicaltech.item.EmberIngotItem;
import magicaltech.item.DimensionIngotItem;

import magicaltech.block.StoneGeneratorBlock;
import magicaltech.block.SpaceAnchorBlock;
import magicaltech.block.SimpleAversionerBlock;
import magicaltech.block.RestorerBlock;
import magicaltech.block.RedstoneGeneratorBlock;
import magicaltech.block.PumpBlock;
import magicaltech.block.PlantGeneratorBlock;
import magicaltech.block.LavaCoreBlock;
import magicaltech.block.InfinityWaterSourceBlock;
import magicaltech.block.InfinityLavaSourceBlock;
import magicaltech.block.FluidStorageCoreBlock;
import magicaltech.block.EnergyStorageCoreBlock;
import magicaltech.block.CoveredInfinityWaterSourceBlock;
import magicaltech.block.CoveredInfinityLavaSourceBlock;
import magicaltech.block.BGMBlock;
import magicaltech.block.AversionerBlock;

import magicaltech.MagicaltechMod;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

public class ProcedureTooltipsProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@OnlyIn(Dist.CLIENT)
		@SubscribeEvent
		public static void onItemTooltip(ItemTooltipEvent event) {
			if (event != null && event.getPlayer() != null) {
				Entity entity = event.getPlayer();
				ItemStack itemStack = event.getItemStack();
				List<ITextComponent> tooltip = event.getToolTip();
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("tooltip", tooltip);
				dependencies.put("entity", entity);
				dependencies.put("event", event);
				dependencies.put("itemstack", itemStack);
				executeProcedure(dependencies);
			}
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				MagicaltechMod.LOGGER.warn("Failed to load dependency itemstack for procedure ProcedureTooltips!");
			return;
		}
		if (dependencies.get("tooltip") == null) {
			if (!dependencies.containsKey("tooltip"))
				MagicaltechMod.LOGGER.warn("Failed to load dependency tooltip for procedure ProcedureTooltips!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		List<ITextComponent> tooltip = (List<ITextComponent>) dependencies.get("tooltip");
		if (itemstack.getItem() == StoneGeneratorBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u4EA7\u51FA\u77F3\u7C7B\u4EA7\u7269\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u88C5\u8F7D\u5BF9\u5E94\u7684\u5347\u7EA7\u6A21\u5757\u4EE5\u589E\u5F3A\u529F\u80FD\u548C\u6539\u53D8\u4EA7\u7269\u7C7B\u578B\u3002"));
				tooltip.add(new StringTextComponent("\u00A73\u00A7o\u53D1\u660E\u4E8E1999\u5E74\u7684\u5947\u602A\u673A\u5668\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A73\u00A7o\u636E\u4F20\u8A00\u79F0\uFF0C\u5B83\u5728\u201C\u90A3\u573A\u6218\u5F79\u201D\u4E2D\u53D1\u6325\u4E86\u81F3\u5173\u91CD\u8981\u7684\u4F5C\u7528\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == RestorerBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u8FDB\u884C\u8010\u4E45\u4FEE\u590D\u3002"));
				tooltip.add(new StringTextComponent("\u00A73\u00A7o"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == PlantGeneratorBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u4EA7\u51FA\u690D\u7269\u7C7B\u4EA7\u7269\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u9700\u8981\u5BF9\u5E94\u7684\u690D\u7269\u6837\u672C\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A73\u00A7o\u6211\u77E5\u9053\u8611\u83C7\u4E0D\u662F\u690D\u7269\uFF0C\u4F46\u53C8\u6709\u4EC0\u4E48\u5173\u7CFB\u5462\uFF1F"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == SimpleAversionerBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u6307\u5B9A\u4E00\u79CD\u76EE\u6807\uFF0C\u5F53\u5176\u8FDB\u5165\u8303\u56F4\u5185\uFF0C\u5C06\u5176\u653E\u9010\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u751F\u6548\u8303\u56F48\u7C73\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u65E0\u6CD5\u653E\u9010\u8FC7\u4E8E\u5F3A\u5927\u7684\u76EE\u6807\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == AversionerBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u6307\u5B9A\u4E00\u79CD\u6216\u591A\u79CD\u76EE\u6807\uFF0C\u5F53\u5176\u8FDB\u5165\u8303\u56F4\u5185\uFF0C\u5C06\u5176\u653E\u9010\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u751F\u6548\u8303\u56F48\u7C73/64\u7C73\uFF0C\u53EF\u5207\u6362\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A73\u00A7o\u56E0\u73C0\u7279\u5E1D\u56FD\u5DC5\u5CF0\u4E4B\u4F5C\u2014\u2014\u201C\u5929\u5E55\u201D\u7CFB\u7EDF\u4E4B\u4E0A\u7684\u4E00\u4E2A\u90E8\u4EF6\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == BGMBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u968F\u65F6\u95F4\u6D41\u901D\u81EA\u7136\u4EA7\u751F\u80FD\u91CF\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u4EA7\u51FA\u901F\u5EA61FE/t\u3002"));
				tooltip.add(new StringTextComponent("\u00A73\u00A7o\u5176\u5B9E\u662FBase Generator Machine\u7684\u610F\u601D\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == RedstoneGeneratorBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u5728\u9644\u8FD1\u653E\u7F6E\u7EA2\u77F3\u5757\u540E\u4EA7\u751F\u80FD\u91CF\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u4EA7\u51FA\u901F\u5EA64FE/t/\u9762\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A73\u00A7o\u67D0\u79CD\u610F\u4E49\u4E0A\uFF0C\u7EA2\u77F3\u5757\u662F\u4E2A\u65E0\u5C3D\u80FD\u6E90\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == PumpBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u62BD\u53D6\u540E\u65B9\u6D41\u4F53\uFF0C\u8F93\u9001\u5411\u524D\u65B9\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u6700\u5927\u62BD\u53D6256KmB/t"));
				tooltip.add(new StringTextComponent("\u00A7b\u5185\u90E8\u7F13\u5B58/\u6700\u5927\u8F93\u51FA1MmB/t"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == SpaceAnchorBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u5F02\u7A7A\u95F4\u5B58\u50A8\u7CFB\u7EDF\u7684\u7ED3\u6784\u7EC4\u4EF6\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == EnergyStorageCoreBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u5F02\u7A7A\u95F4\u5B58\u50A8\u7CFB\u7EDF\u7684\u6838\u5FC3\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u7ED3\u6784\u5B8C\u6210\u540E\uFF0C\u4F7F\u7528\u7A7A\u95F4\u6273\u624B\u53F3\u51FB\u4EE5\u6FC0\u6D3B\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == FluidStorageCoreBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u5F02\u7A7A\u95F4\u5B58\u50A8\u7CFB\u7EDF\u7684\u6838\u5FC3\u3002"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u7ED3\u6784\u5B8C\u6210\u540E\uFF0C\u4F7F\u7528\u7A7A\u95F4\u6273\u624B\u53F3\u51FB\u4EE5\u6FC0\u6D3B\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == LavaCoreBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent("\u00A7b\u661F\u6838\u7194\u6CC9\u4E4B\u6E90\u7684\u6846\u67B6\u3002"));
				tooltip.add(new StringTextComponent("\u00A7b\u9700\u6CE8\u516510MmB\u7194\u5CA9\u4EE5\u6FC0\u6D3B\u3002"));
				tooltip.add(new StringTextComponent("\u00A73\u00A7o\u5E76\u4E0D\u4FBF\u643A\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == InfinityLavaSourceBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u5B58\u6709\u65E0\u5C3D\u7684\u7194\u5CA9\uFF0C\u5E76\u53EF\u5411\u6BCF\u4E2A\u9762\u4EE5\u4E00\u5B9A\u901F\u5EA6\u8F93\u51FA\u7194\u5CA9\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == CoveredInfinityLavaSourceBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u5B58\u6709\u65E0\u5C3D\u7684\u7194\u5CA9\uFF0C\u5E76\u53EF\u5411\u6307\u5B9A\u9762\u4EE5\u4E00\u5B9A\u901F\u5EA6\u8F93\u51FA\u7194\u5CA9\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == InfinityWaterSourceBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u5B58\u6709\u65E0\u5C3D\u7684\u6C34\uFF0C\u5E76\u53EF\u5411\u6BCF\u4E2A\u9762\u4EE5\u6781\u5927\u901F\u5EA6\u8F93\u51FA\u6C34\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == CoveredInfinityWaterSourceBlock.block.asItem()) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u53EF\u4EE5\u653E\u7F6E"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u5B58\u6709\u65E0\u5C3D\u7684\u6C34\uFF0C\u5E76\u53EF\u5411\u6307\u5B9A\u9762\u4EE5\u6781\u5927\u901F\u5EA6\u8F93\u51FA\u6C34\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == EmptyRuneItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent("\u00A7b\u7528\u4E8E\u523B\u5370\u7B26\u6587\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == TrueRuneItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A7b\u7F16\u7A0B\u7535\u8DEF\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == FalseRuneItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A7b\u7F16\u7A0B\u7535\u8DEF\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == TerraSpiritualIngotItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u4F17\u591A\u77FF\u7269\u4E4B\u7CBE\u534E\u3002\u4E0D\u65F6\u6709\u6676\u83B9\u7684\u6D41\u5149\u5728\u8868\u9762\u95EA\u70C1\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == EmberIngotItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u6781\u7AEF\u9177\u70ED\u4E4B\u5730\u7684\u7F29\u5F71\u3002\u4E0D\u8BBA\u8FC7\u53BB\u591A\u4E45\uFF0C\u4ECD\u4FDD\u7559\u7740\u4E00\u4E1D\u4F59\u6E29\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == DimensionIngotItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u6700\u521D\u81EA\u6DF7\u6C8C\u4E2D\u8BDE\u751F\u7684\u4E09\u4E2A\u7EF4\u5EA6\uFF0C\u5176\u57FA\u77F3\u7194\u878D\u4E3A\u4E00\uFF0C\u6620\u886C\u7740\u4F60\u7684\u65C5\u9014\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
		if (itemstack.getItem() == SkieumIngotItem.block) {
			if (Screen.hasShiftDown()) {
				tooltip.add(new StringTextComponent("\u00A79\u6750\u6599"));
				tooltip.add(new StringTextComponent(
						"\u00A7b\u795E\u79D8\u7684\u661F\u7A7A\uFF0C\u81EA\u53E4\u4EE5\u6765\u5C31\u4E3A\u4EBA\u4EEC\u6240\u5411\u5F80\u3002\u800C\u4F60\u7AA5\u63A2\u5230\u4E86\u5B83\u7684\u4E00\u4E1D\u5965\u5999\u3002"));
			} else {
				tooltip.add(new StringTextComponent("\u00A7b<Shift>"));
			}
		}
	}
}
