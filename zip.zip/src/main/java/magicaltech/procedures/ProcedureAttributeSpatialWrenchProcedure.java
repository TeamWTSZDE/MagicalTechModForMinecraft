package magicaltech.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.ItemAttributeModifierEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.entity.ai.attributes.AttributeModifier;

import magicaltech.item.SpatialWrenchItem;

import magicaltech.MagicaltechMod;

import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

public class ProcedureAttributeSpatialWrenchProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void addAttributeModifier(ItemAttributeModifierEvent event) {
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("itemstack", event.getItemStack());
			dependencies.put("event", event);
			executeProcedure(dependencies);
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				MagicaltechMod.LOGGER.warn("Failed to load dependency itemstack for procedure ProcedureAttributeSpatialWrench!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		if (dependencies.get("event") instanceof ItemAttributeModifierEvent
				&& ((ItemAttributeModifierEvent) dependencies.get("event")).getSlotType() == EquipmentSlotType.MAINHAND) {
			ItemAttributeModifierEvent _event = (ItemAttributeModifierEvent) dependencies.get("event");
			if (itemstack.getItem() == SpatialWrenchItem.block) {
				_event.addModifier(net.minecraft.entity.ai.attributes.Attributes.MOVEMENT_SPEED,
						(new AttributeModifier(UUID.fromString("5456594d-9994-4a1e-a1ac-f4d42a5b1cd3"), "magicaltech." + "SPAD", 0.04,
								AttributeModifier.Operation.ADDITION)));
				_event.addModifier(net.minecraft.entity.ai.attributes.Attributes.ATTACK_DAMAGE,
						(new AttributeModifier(UUID.fromString("5105814f-5a23-42c1-973d-12dc0c3791ce"), "magicaltech." + "ATCK", 4,
								AttributeModifier.Operation.ADDITION)));
			}
		}
	}
}
