
package magicaltech.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import magicaltech.itemgroup.ItemGroupItemGroup;

import magicaltech.MagicaltechModElements;

@MagicaltechModElements.ModElement.Tag
public class DimensionIngotItem extends MagicaltechModElements.ModElement {
	@ObjectHolder("magicaltech:material_ingot_dimension")
	public static final Item block = null;

	public DimensionIngotItem(MagicaltechModElements instance) {
		super(instance, 48);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(ItemGroupItemGroup.tab).maxStackSize(64).isImmuneToFire().rarity(Rarity.RARE));
			setRegistryName("material_ingot_dimension");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
